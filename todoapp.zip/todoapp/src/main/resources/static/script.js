window.onload = loadTasks;

// LOGIN
function loginUser() {

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if (username == "admin" && password == "1234") {
        window.location.href = "/home";
    } else {
        alert("Invalid Username or Password");
    }
}

// ADD TASK
function addTask() {

    let taskTitle = document.getElementById("taskTitle").value;
    let taskDescription = document.getElementById("taskDescription").value;

    if (taskTitle == "") {
        alert("Enter Task Title");
        return;
    }

    fetch("/tasks", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: taskTitle,
            description: taskDescription,
            status: false
        })
    })
    .then(response => response.json())
    .then(() => {
        loadTasks();
        document.getElementById("taskTitle").value = "";
        document.getElementById("taskDescription").value = "";
    });
}

// LOAD TASKS
function loadTasks() {

    fetch("/tasks")
    .then(response => response.json())
    .then(tasks => {

        let output = "";

        tasks.forEach(task => {

            output += `
                <div class="task-box">

                    <b>${task.title}</b><br>
                    ${task.description}<br><br>

                    Status: ${task.status ? "Completed" : "Pending"}

                    <br><br>

                    <button onclick="completeTask(${task.id}, '${task.title}', '${task.description}')">Done</button>

                    <button onclick="editTask(${task.id}, '${task.title}', '${task.description}', ${task.status})">Edit</button>

                    <button onclick="deleteTask(${task.id})">Delete</button>

                    <hr>
                </div>
            `;
        });

        document.getElementById("taskList").innerHTML = output;
    });
}

// DELETE
function deleteTask(id) {

    fetch("/tasks/" + id, {
        method: "DELETE"
    })
    .then(() => loadTasks());
}

// DONE BUTTON FIXED
function completeTask(id, title, description) {

    fetch("/tasks/" + id, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            id: id,
            title: title,
            description: description,
            status: true
        })
    })
    .then(() => loadTasks());
}

// EDIT
function editTask(id, oldTitle, oldDescription, oldStatus) {

    let newTitle = prompt("Edit Title", oldTitle);
    let newDescription = prompt("Edit Description", oldDescription);

    if (newTitle == null || newTitle == "") return;

    fetch("/tasks/" + id, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            id: id,
            title: newTitle,
            description: newDescription,
            status: oldStatus
        })
    })
    .then(() => loadTasks());
}