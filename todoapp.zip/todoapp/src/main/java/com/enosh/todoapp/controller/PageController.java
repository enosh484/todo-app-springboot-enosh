package com.enosh.todoapp.controller;

import org.springframework.stereotype.Controller;


import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

  

    @GetMapping("/home")
    public String homePage() {
        return "home";
    }
}