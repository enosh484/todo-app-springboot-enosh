package com.enosh.todoapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.enosh.todoapp.model.Task;

public interface TaskRepository extends JpaRepository<Task, Integer> {

}