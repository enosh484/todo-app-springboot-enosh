package com.enosh.todoapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import com.enosh.todoapp.model.Task;
import com.enosh.todoapp.repository.TaskRepository;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    @Autowired
    private TaskRepository repo;

    // ✅ CREATE (POST)
    @PostMapping
    public Task addTask(@RequestBody Task task) {
        return repo.save(task);
    }

    // ✅ READ ALL (GET)
    @GetMapping
    public List<Task> getAllTasks() {
        return repo.findAll();
    }

    // ✅ READ BY ID (GET)
    @GetMapping("/{id}")
    public Task getTaskById(@PathVariable int id) {
        Optional<Task> task = repo.findById(id);
        return task.orElse(null);
    }
    

    // ✅ UPDATE (PUT)
    @PutMapping("/{id}")
    public Task updateTask(@PathVariable int id, @RequestBody Task newTask) {

        Optional<Task> optionalTask = repo.findById(id);

        if (optionalTask.isPresent()) {
            Task existing = optionalTask.get();

            existing.setTitle(newTask.getTitle());
            existing.setDescription(newTask.getDescription());
            existing.setStatus(newTask.isStatus());

            return repo.save(existing);
        }

        return null; // if not found
    }

    // ✅ DELETE (DELETE)
    @DeleteMapping("/{id}")
    public String deleteTask(@PathVariable int id) {
        repo.deleteById(id);
        return "Task deleted successfully";
    }
   
}